document.getElementById('box').onclick = function(){
    alert('珠峰');
}