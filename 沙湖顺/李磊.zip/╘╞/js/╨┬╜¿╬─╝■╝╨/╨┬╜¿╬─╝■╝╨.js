

/*
   1,创建文件夹
   2，点击创建文件夹，先在box中创建一个folder的元素，然后当folder中的input失焦后在添加数据到ary中，
      之后通过最新的ary渲染页面即可
   3.当失焦时把新的数据push到ary中，并且通过了新的数据进行渲染页面
 
*/





let ary = [{
        "id": 1,
        "pid": 0,
        "title": "新建文件夹",
        "type": "file",
        "checked": true
    }];
    // for (k in data) {
    //     ary.push(data[k])     
    // }
    $("#create").click(function () {
        render(ary);
    });
    
    function render(ary){
    
        // $('#box').html('');
        $.each(ary,(i,item)=>{
            //创建文件夹
    
            const {checked,id,title} = item;
    
      console.log(title)
      console.log(title.name)
             let $folder = $(`
               <div  class="file-item ${checked?'active':''}" did="${id}">
    <img src="img/folder-b.png" alt="" />
    <span class="folder-name">${title}</span>
    <input type="text" value="${title}" class="editor"/>
    <i class=${checked?"checked":''}></i>
    </div>
                   `);
            $folder.find('input').hide();
            $('.folders').append($folder);
        });
    }